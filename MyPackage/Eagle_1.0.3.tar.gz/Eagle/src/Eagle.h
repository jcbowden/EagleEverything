 #include <omp.h> 
 #include <iostream> 
 #include <fstream> 
 #include <istream> 
 #include <vector> 
 #include <bitset> 
 #include <string> 
 using namespace std;
    
